"""
Project Name: Shoonya unofficial Python sdk

Description:
This project is Shoonya unofficial Python sdk

Author: Sanju 
Telegram: @KoinGuru
Created On: 2026-07-12

Features:
- Oauth implemented
- No need browser automation
- Broker API integration

"""


import json
import orjson
import struct
import requests
import threading
import websocket
import logging
import enum
import datetime
import hashlib
import time
import urllib
from time import sleep
from datetime import datetime as dt
import websocket._app as _ws_app

logger = logging.getLogger(__name__)

class position:
    prd:str
    exch:str
    instname:str
    symname:str
    exd:int
    optt:str
    strprc:float
    buyqty:int
    sellqty:int
    netqty:int
    def encode(self):
        return self.__dict__

class ProductType:
    Delivery = 'C'
    Intraday = 'I'
    Normal   = 'M'
    CF       = 'M'

class FeedType:
    TOUCHLINE = 1    
    SNAPQUOTE = 2
    
class PriceType:
    Market = 'MKT'
    Limit = 'LMT'
    StopLossLimit = 'SL-LMT'
    StopLossMarket = 'SL-MKT'

class BuyorSell:
    Buy = 'B'
    Sell = 'S'
    
def reportmsg(msg):
    #print(msg)
    logger.debug(msg)

def reporterror(msg):
    #print(msg)
    logger.error(msg)

def reportinfo(msg):
    #print(msg)
    logger.info(msg)


class NorenApi:
    __service_config = {
      'host': 'https://api.shoonya.com/NorenWClientAPI/',
      'routes': {
          'authorize': '/QuickAuth',
          'logout': '/Logout',
          'forgot_password': '/ForgotPassword',
          'change_password': '/Changepwd',
          'watchlist_names': '/MWList',
          'watchlist': '/MarketWatch',
          'watchlist_add': '/AddMultiScripsToMW',
          'watchlist_delete': '/DeleteMultiMWScrips',
          'placeorder': '/PlaceOrder',
          'modifyorder': '/ModifyOrder',
          'cancelorder': '/CancelOrder',
          'exitorder': '/ExitSNOOrder',
          'product_conversion': '/ProductConversion',
          'orderbook': '/OrderBook',
          'tradebook': '/TradeBook',          
          'singleorderhistory': '/SingleOrdHist',
          'searchscrip': '/SearchScrip',
          'TPSeries' : '/TPSeries',     
          'optionchain' : '/GetOptionChain',     
          'holdings' : '/Holdings',
          'limits' : '/Limits',
          'positions': '/PositionBook',
          'scripinfo': '/GetSecurityInfo',
          'getquotes': '/GetQuotes',
          'span_calculator' :'/SpanCalc',
          'option_greek' :'/GetOptionGreek',
          'get_daily_price_series' :'/EODChartData',
          'forgot_password_OTP':'/FgtPwdOTP',
          'gen_acs_tok':'/GenAcsTok'
      },
      'websocket_endpoint': 'wss://api.shoonya.com/NorenWSAPI',
      #'eoddata_endpoint' : 'http://eodhost/'
    }

    def __init__(self, host, websocket):
        self.__service_config['host'] = host
        self.__service_config['websocket_endpoint'] = websocket
        #self.__service_config['eoddata_endpoint'] = eodhost
        self.__access_token = None
        self.__username = None
        self.__accountid = None        
        self.__websocket = None
        self.__websocket_connected = False
        self.__ws_mutex = threading.Lock()
        self.__on_error = None
        self.__on_disconnect = None
        self.__on_open = None
        self.__subscribe_callback = None
        self.__order_update_callback = None
        self.__subscribers = {}
        self.__market_status_messages = []
        self.__exchange_messages = []
        self.__OAuthHeaders = None

        self.ws_auth_failed = False
        self.__resubscribe = False

        self.__tl_set = set() 
        self.__sq_set = set()


        for attr in ('__subscribe_callback', '__order_update_callback', '__on_error', '__on_open', '__broadcast_callback'):
            setattr(self, attr, self.__dummy_callback)

    def __ws_send(self, *args, **kwargs):
        #while self.__websocket_connected == False:
        while not self.__websocket_connected:
            sleep(0.05)  # sleep for 50ms if websocket is not connected, wait for reconnection
        with self.__ws_mutex:
            ret = self.__websocket.send(*args, **kwargs)
        return ret


    def __on_close_callback(self, wsapp, close_status_code, close_msg):
        reportmsg(close_status_code)
        reportmsg(wsapp)

        self.__websocket_connected = False
        if self.__on_disconnect:
            self.__on_disconnect()
    
    def set_credentials(self, access_token, uid, accountid):
        self.__access_token = access_token
        self.__username = uid
        self.__accountid = accountid
    
    def __dummy_callback(self, msg= None):
        pass

    def __on_open_callback(self, ws=None, access_token: str= None):
        self.__websocket_connected = True
        values              = { "t": "a" }
        values["uid"]       = self.__username        
        values["actid"]     = self.__username
        values["accesstoken"]    = access_token
        values["source"]    = 'API'   
           
        payload = json.dumps(values)

        reportmsg(payload)
        self.__ws_send(payload)

        #self.__resubscribe()
        

    def __on_error_callback(self, ws=None, error=None):
        if(type(ws) is not websocket.WebSocketApp): # This workaround is to solve the websocket_client's compatiblity issue of older versions. ie.0.40.0 which is used in upstox. Now this will work in both 0.40.0 & newer version of websocket_client
            error = ws
        if self.__on_error:
            self.__on_error(error)

    def __on_data_callback(self, ws=None, message=None, data_type=None, continue_flag=None):
        #print(ws)
        #print(message)
        #print(data_type)
        #print(continue_flag)

        res = orjson.loads(message)

        '''
        if(self.__subscribe_callback is not None):
            if res['t'] == 'tk' or res['t'] == 'tf':
                self.__subscribe_callback(res)
                return
            if res['t'] == 'dk' or res['t'] == 'df':
                self.__subscribe_callback(res)
                return

        if(self.__on_error is not None):
            if res['t'] == 'ak' and res['s'] != 'OK':
                self.__on_error(res)
                return

        if(self.__order_update_callback is not None):
            if res['t'] == 'om':
                self.__order_update_callback(res)
                return

        if self.__on_open:
            if res['t'] == 'ak' and res['s'] == 'OK':
                self.__on_open()
                return
        '''
        t = res['t']
        if t in {'df', 'tf', 'dk', 'tk'}:
            self.__subscribe_callback(res)
        elif t == 'om':
            self.__order_update_callback(res)
        elif t in {'ak', 'ck'}:
            if res['s'] != 'OK': 
                self.__on_error(res)
            else:
                if self.__resubscribe:
                    if self.__tl_set: 
                        self.subscribe(list(self.__tl_set), FeedType.TOUCHLINE)
                    if self.__sq_set: 
                        self.subscribe(list(self.__sq_set), FeedType.SNAPQUOTE)
                self.__on_open()
        elif t in {'am', 'ms'}:
            self.__broadcast_callback(res)
    

    def start_websocket(self, subscribe_callback = None, 
                        order_update_callback = None,
                        socket_open_callback = None,
                        socket_close_callback = None,
                        socket_error_callback = None,
                        access_token = None,
                        resubscribe = True
                    ):    
        """ Start a websocket connection for getting live data """
        self.__on_open = socket_open_callback
        self.__on_disconnect = socket_close_callback
        self.__on_error = socket_error_callback
        self.__subscribe_callback = subscribe_callback
        self.__order_update_callback = order_update_callback
        self.__stop_event = threading.Event()
        
        access_token = self.__access_token
        
        
        self.__resubscribe = resubscribe

        #reportmsg(access_token)

        url = f"{self.__service_config['websocket_endpoint']}/{access_token}"
        print(url)
        reportmsg('connecting to {}'.format(url))

        api_self = self 

        websocket_run_forever = _ws_app.WebSocketApp.run_forever

        def __run_forever(ws_app, *args, **kwargs):
            reconnect = kwargs.get('reconnect', 0)
            _recv_frame = websocket.WebSocket.recv_frame

            def __recv_frame(ws_inner):
                frame = _recv_frame(ws_inner)
                if (
                        reconnect
                        and frame.opcode == websocket.ABNF.OPCODE_CLOSE
                        and len(frame.data) >= 2
                        and struct.unpack('!H', frame.data[:2])[0] == 1008
                        ):
                    ws_app.keep_running = False
                    api_self.ws_auth_failed = True
                return frame

            websocket.WebSocket.recv_frame = __recv_frame
            try:
                return websocket_run_forever(ws_app, *args, **kwargs)
            finally:
                websocket.WebSocket.recv_frame = _recv_frame

        _ws_app.WebSocketApp.run_forever = __run_forever

        self.__websocket = websocket.WebSocketApp(
                                                    url,
                                                    on_data=self.__on_data_callback,
                                                    on_error=self.__on_error_callback,
                                                    on_close=self.__on_close_callback,
                                                    on_open= lambda ws: self.__on_open_callback(
                                                                                                    ws= ws, 
                                                                                                    access_token= access_token
                                                                                                )
                                            )

        threading.Thread(
            target=self.__websocket.run_forever,
            kwargs=dict(ping_interval=3, ping_timeout=2, ping_payload='{"t":"h"}', reconnect=1), 
            daemon=True
        ).start()

        
    def close_websocket(self):
        if not self.__websocket_connected:
            return
        self.__stop_event.set()        
        self.__websocket_connected = False
        self.__websocket.close()
        #self.__ws_thread.join()

    ###### OAuth Update ###### 
    def getOAuthURL(self, oauth_url, api_key=None): 
        default_login_uri = oauth_url 
        return "%s?client_id=%s" % (default_login_uri, api_key)

    def injectOAuthHeader(self,access_token,UID,AID): 
        headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json; charset=utf-8"
        }
        self.__OAuthHeaders = headers
        self.__username   = UID
        self.__accountid  = AID
        return headers
    
    def getAccessToken(self, authcode, Secret_Code, client_id, UID): 
        config = NorenApi.__service_config
        AcsTokURL = f"{config['host']}{config['routes']['gen_acs_tok']}" 
        reportmsg(AcsTokURL)
        GenAcsTokURL=AcsTokURL
        data_to_hash = (client_id + Secret_Code + authcode).encode("utf-8")
        app_verifier = hashlib.sha256(data_to_hash).hexdigest()

        values = {
            "code": authcode,
            "checksum": app_verifier,
            "uid": UID
        }

        payload = 'jData=' + json.dumps(values)
        reportmsg("Req:" + payload)

        res = requests.post(GenAcsTokURL, data=payload)
        reportmsg("Response:" + res.text)
        resDict = json.loads(res.text)
        if "access_token" in resDict:
            asc_tok = resDict['access_token']
            usrid = resDict['USERID']
            ref_tok = resDict['refresh_token']
            actid = resDict['actid']
            self.__susertoken = resDict['susertoken']

            self.__username   = usrid
            self.__accountid  = actid
            self.__access_token = asc_tok
            self.injectOAuthHeader(asc_tok,usrid,actid)
            return asc_tok , usrid , ref_tok, actid

        else:        
            reportmsg(f"Error occured: {resDict}")
            return None

      
    ###### OAuth Update ###### 
                           
    def authenticate(self,USER_ID, PASSWORD,SECRET_CODE, IMEI, APPKEY,TWOfa):
        config = NorenApi.__service_config
        CLIENT_ID = f"{USER_ID}_U"
        quickauth_url = f"{config['host']}{config['routes']['authorize']}"
        login_url = (
            f"https://api.shoonya.com/OAuthlogin/investor-entry-level/login"
            f"?api_key={CLIENT_ID}&route_to={USER_ID}"
        )

        session = requests.Session()
        session.headers.update({
            "user-agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
            ),
            "accept": "application/json, text/plain, */*",
            "accept-language": "en-US,en;q=0.9",
            "sec-ch-ua": '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "priority": "u=1, i",
            "origin": "https://api.shoonya.com",
            "referer": login_url,
        })

        session.get(login_url, timeout=15)
        pwd_hash = hashlib.sha256(PASSWORD.encode()).hexdigest()
        appkey = APPKEY #hashlib.sha256(f"{USER_ID}|{SECRET_CODE}".encode()).hexdigest()

        payload = {
            "apkversion": "W2_20250926",
            "uid": USER_ID,
            "pwd": pwd_hash,
            "factor2": TWOfa,
            "appkey": appkey,
            "imei": IMEI,
            "addldivinf": session.headers["user-agent"],
            "source": "API",
            "vc": "NOREN_API",   
            "app_key": CLIENT_ID,  
        }

        try:
            resp = session.post(
                quickauth_url,
                data="jData=" + json.dumps(payload),
                headers={"content-type": "application/x-www-form-urlencoded"},
                timeout=15,
            )
        except Exception as e:
            print(f"❌ QuickAuth request raised an exception: {e}")
            return None

        #print("🔎 OAuth server response:", resp.status_code, resp.text)

        try:
            result = resp.json()
        except ValueError:
            print("❌ Response was not JSON.")
            return None

        if result.get("stat") != "Ok":
            print("❌ OAuth failed:", result.get("emsg", result))
            return None

        Auth_code = result.get("code")
        print("✅ Authenticated, got code")
        return Auth_code

    def get_api_token(self,auth_code,CLIENT_ID,SECRET_CODE):
        """Exchange auth code for API token"""
        checksum = hashlib.sha256(
            (CLIENT_ID + SECRET_CODE + auth_code).encode()
        ).hexdigest()

        TOKEN_URL = "https://api.shoonya.com/NorenWClientAPI/GenAcsTok"

        payload = f'jData={{"code":"{auth_code}","checksum":"{checksum}"}}'
        headers = {"Authorization": f"Bearer {checksum}"}
        response = requests.post(TOKEN_URL, data=payload, headers=headers)
        try:
            data = response.json()
            return data #data.get("ActTok") or data.get("access_token")
        except:
            print("❌ Token parsing failed")
            print(response.text)
            return None



    def login(self, userid, password, twoFA, vendor_code, api_secret, imei, secret_code, appkey):
        auth_code = self.authenticate(userid, password, secret_code, imei, appkey,twoFA)
        if not auth_code:
            print("❌ O Auth code failed")
            return
        
        resD = self.get_api_token(auth_code,f"{userid}_U",secret_code)
        #api_token = self.getAccessToken(auth_code,secret_code,f"{userid}_U",userid)

        if not resD:
            print("❌ api_token Auth failed")
            return

        #print("🔑 API Token:", api_token)
        with open("apitoken.txt", "a", encoding="utf-8") as f:
                f.write(str(resD.get("ActTok") or resD.get("access_token")) + "\n")
        self.set_session(userid, resD.get("access_token"))
        return resD

       
    def set_session(self, userid, accesstoken):
        
        self.__username   = userid
        self.__accountid  = userid
        #self.__password   = password
        #self.__susertoken = usertoken
        self.__access_token = accesstoken

        reportmsg(f'{userid} session set to : {self.__access_token}')

        self.injectOAuthHeader(accesstoken, userid, userid)

        return True

    def forgot_password(self, userid, pan, dob):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['forgot_password']}" 
        reportmsg(url)

        #prepare the data
        values              = { "source": "API" }
        values["uid"]       = userid
        values["pan"]       = pan
        values["dob"]       = dob

        payload = 'jData=' + json.dumps(values)
        reportmsg("Req:" + payload)

        res = requests.post(url, data=payload)
        reportmsg("Reply:" + res.text)

        resDict = json.loads(res.text)
        
        if resDict['stat'] != 'Ok':            
            return None
        
        return resDict

    def logout(self):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['logout']}" 
        reportmsg(url)
        #prepare the data
        values              = {'ordersource':'API'}
        values["uid"]       = self.__username
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)

        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)
        if resDict['stat'] != 'Ok':            
            return None

        self.__username   = None
        self.__accountid  = None
        self.__password   = None
        self.__susertoken = None
        self.__access_token = None

        return resDict

    '''
    def subscribe(self, instrument, feed_type=FeedType.TOUCHLINE):
        values = {}

        if(feed_type == FeedType.TOUCHLINE):
            values['t'] =  't'
        elif(feed_type == FeedType.SNAPQUOTE):
            values['t'] =  'd'
        else:
            values['t'] =  str(feed_type)

        if type(instrument) == list:
            values['k'] = '#'.join(instrument)
        else :
            values['k'] = instrument

        data = json.dumps(values)

        #print(data)
        self.__ws_send(data)
    '''

    def subscribe(self, instrument, feed_type=FeedType.TOUCHLINE, batch_size= 30, delay= .1):
        t = threading.Thread(target=self.__subscribe_worker, args=(instrument, feed_type, batch_size, delay), daemon=True)
        t.start()

    def __subscribe_worker(self, instrument, feed_type, batch_size, delay):
        ft = {'t':'t', FeedType.TOUCHLINE:'t', 'd':'d', FeedType.SNAPQUOTE:'d'}.get(feed_type)

        if not ft: return

        tokens = instrument if isinstance(instrument, list) else [instrument]

        if self.__resubscribe:
            (self.__tl_set if ft=='t' else self.__sq_set).update(tokens)

        [self.__ws_send(json.dumps({'t':ft,'k':'#'.join(tokens[i:i+batch_size])})) or time.sleep(delay) for i in range(0,len(tokens),batch_size)]

    '''
    def unsubscribe(self, instrument, feed_type=FeedType.TOUCHLINE):
        values = {}

        if(feed_type == FeedType.TOUCHLINE):
            values['t'] =  'u'
        elif(feed_type == FeedType.SNAPQUOTE):
            values['t'] =  'ud'
        
        if type(instrument) == list:
            values['k'] = '#'.join(instrument)
        else :
            values['k'] = instrument

        data = json.dumps(values)

        #print(data)
        self.__ws_send(data)
    '''

    def unsubscribe(self, instrument, feed_type=FeedType.TOUCHLINE):
        ft = {'t':'u', FeedType.TOUCHLINE:'u', 'd':'ud', FeedType.SNAPQUOTE:'ud'}.get(feed_type)

        if not ft: return

        tokens = instrument if isinstance(instrument, list) else [instrument]

        if self.__resubscribe:
            (self.__tl_set if ft=='u' else self.__sq_set).difference_update(tokens)

        self.__ws_send(json.dumps({'t':ft,'k':'#'.join(tokens)}))

    def subscribe_orders(self):
        values = {'t': 'o'}
        values['actid'] = self.__accountid        

        data = json.dumps(values)

        reportmsg(data)
        self.__ws_send(data)

    def get_watch_list_names(self):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['watchlist_names']}" 
        reportmsg(url)
        #prepare the data
        values              = {'ordersource':'API'}
        values["uid"]       = self.__username
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)
        if resDict['stat'] != 'Ok':            
            return None

        return resDict

    def get_watch_list(self, wlname):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['watchlist']}" 
        reportmsg(url)
        #prepare the data
        values              = {'ordersource':'API'}
        values["uid"]       = self.__username
        values["wlname"]    = wlname
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)
        if resDict['stat'] != 'Ok':            
            return None

        return resDict


    def add_watch_list_scrip(self, wlname, instrument):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['watchlist_add']}" 
        reportmsg(url)
        #prepare the data
        values              = {'ordersource':'API'}
        values["uid"]       = self.__username
        values["wlname"]    = wlname

        if type(instrument) == list:
            values['scrips'] = '#'.join(instrument)
        else :
            values['scrips'] = instrument
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'   
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)
        if resDict['stat'] != 'Ok':            
            return None

        return resDict

    def delete_watch_list_scrip(self, wlname, instrument):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['watchlist_delete']}" 
        reportmsg(url)
        #prepare the data
        values              = {'ordersource':'API'}
        values["uid"]       = self.__username
        values["wlname"]    = wlname

        if type(instrument) == list:
            values['scrips'] = '#'.join(instrument)
        else :
            values['scrips'] = instrument
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)
        if resDict['stat'] != 'Ok':            
            return None

        return resDict


    def place_order(self, buy_or_sell, product_type,
                    exchange, tradingsymbol, quantity, discloseqty,
                    price_type, price=0.0, trigger_price=None,
                    retention='DAY', amo=None, remarks=None, bookloss_price = 0.0, bookprofit_price = 0.0, trail_price = 0.0, algo_id=None):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['placeorder']}" 
        reportmsg(url)
        #prepare the data
        values              = {'ordersource':'API'}
        values["uid"]       = self.__username
        values["actid"]     = self.__accountid
        values["trantype"]  = buy_or_sell
        values["prd"]       = product_type
        values["exch"]      = exchange
        values["tsym"]      = urllib.parse.quote_plus(tradingsymbol)
        values["qty"]       = str(quantity)
        values["dscqty"]    = str(discloseqty)        
        values["prctyp"]    = price_type
        values["prc"]       = str(price)
        values["trgprc"]    = str(trigger_price)
        values["ret"]       = retention
        values["remarks"]   = remarks
        values["algo_id"]       = algo_id

      
        if amo is not None:
           values["amo"]       = amo
        
        #if cover order or high leverage order
        if product_type == 'H':            
            values["blprc"]       = str(bookloss_price)
            #trailing price
            if trail_price != 0.0:
                values["trailprc"] = str(trail_price)

        #bracket order
        if product_type == 'B':            
            values["blprc"]       = str(bookloss_price)
            values["bpprc"]       = str(bookprofit_price)
            #trailing price
            if trail_price != 0.0:
                values["trailprc"] = str(trail_price)

        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)
        if resDict['stat'] != 'Ok':            
            return None

        return resDict

    def modify_order(self, orderno, exchange, tradingsymbol, newquantity,
                    newprice_type, newprice=0.0, newtrigger_price=None, bookloss_price = 0.0, bookprofit_price = 0.0, trail_price = 0.0):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['modifyorder']}" 
        print(url)

        #prepare the data
        values                  = {'ordersource':'API'}
        values["uid"]           = self.__username
        values["actid"]         = self.__accountid
        values["norenordno"]    = str(orderno)
        values["exch"]          = exchange
        values["tsym"]          = urllib.parse.quote_plus(tradingsymbol)
        values["qty"]           = str(newquantity)
        values["prctyp"]        = newprice_type        
        values["prc"]           = str(newprice)

        if (newprice_type == 'SL-LMT') or (newprice_type == 'SL-MKT'):
            if (newtrigger_price != None):
                values["trgprc"] = str(newtrigger_price)
            else:
                reporterror('trigger price is missing')
                return None

        #if cover order or high leverage order
        if bookloss_price != 0.0:            
            values["blprc"]       = str(bookloss_price)
        #trailing price
        if trail_price != 0.0:
            values["trailprc"] = str(trail_price)         
        #book profit of bracket order   
        if bookprofit_price != 0.0:
            values["bpprc"]       = str(bookprofit_price)
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)
        if resDict['stat'] != 'Ok':            
            return None

        return resDict

    def cancel_order(self, orderno):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['cancelorder']}" 
        print(url)

        #prepare the data
        values              = {'ordersource':'API'}
        values["uid"]       = self.__username
        values["norenordno"]    = str(orderno)
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        print(res.text)

        resDict = json.loads(res.text)
        if resDict['stat'] != 'Ok':            
            return None

        return resDict

    def exit_order(self, orderno, product_type):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['exitorder']}" 
        print(url)

        #prepare the data
        values              = {'ordersource':'API'}
        values["uid"]       = self.__username
        values["norenordno"]    = orderno
        values["prd"]           = product_type
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)
        if resDict['stat'] != 'Ok':            
            return None

        return resDict

    def position_product_conversion(self, exchange, tradingsymbol, quantity, new_product_type, previous_product_type, buy_or_sell, day_or_cf):
        '''
        Coverts a day or carryforward position from one product to another. 
        '''
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['product_conversion']}" 
        print(url)

        #prepare the data
        values              = {'ordersource':'API'}
        values["uid"]       = self.__username
        values["actid"]     = self.__accountid        
        values["exch"]      = exchange
        values["tsym"]      = urllib.parse.quote_plus(tradingsymbol)
        values["qty"]       = str(quantity)
        values["prd"]       = new_product_type
        values["prevprd"]   = previous_product_type
        values["trantype"]  = buy_or_sell
        values["postype"]   = day_or_cf
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)
        
        if resDict['stat'] != 'Ok':            
            return None

        return resDict


    def single_order_history(self, orderno):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['singleorderhistory']}" 
        print(url)
        
        #prepare the data
        values              = {'ordersource':'API'}
        values["uid"]       = self.__username
        values["norenordno"]    = orderno
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)
        #error is a json with stat and msg wchih we printed earlier.
        if type(resDict) != list:                            
                return None

        return resDict


    def get_order_book(self):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['orderbook']}" 
        reportmsg(url)

        #prepare the data
        values              = {'ordersource':'API'}
        values["uid"]       = self.__username
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)
        
        #error is a json with stat and msg wchih we printed earlier.
        if type(resDict) != list:                            
                return None

        return resDict

    def get_trade_book(self):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['tradebook']}"
        reportmsg(url)

        #prepare the data
        values              = {} #{'ordersource':'API'}
        values["uid"]       = self.__username
        values["actid"]     = self.__accountid
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)
        
        #error is a json with stat and msg wchih we printed earlier.
        if type(resDict) != list:                            
            return None

        return resDict

    def searchscrip(self, exchange, searchtext):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['searchscrip']}" 
        reportmsg(url)
        
        if searchtext == None:
            reporterror('search text cannot be null')
            return None
        
        values              = {}
        values["uid"]       = self.__username
        values["exch"]      = exchange
        values["stext"]     = urllib.parse.quote_plus(searchtext)       
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)

        if resDict['stat'] != 'Ok':            
            return None        

        return resDict

    def get_option_chain(self, exchange, tradingsymbol, strikeprice, count=2):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['optionchain']}" 
        reportmsg(url)
        
        
        values              = {}
        values["uid"]       = self.__username
        values["exch"]      = exchange
        values["tsym"]      = urllib.parse.quote_plus(tradingsymbol)       
        values["strprc"]    = str(strikeprice)
        values["cnt"]       = str(count)       
        
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)

        if resDict['stat'] != 'Ok':            
            return None        

        return resDict

    def get_security_info(self, exchange, token):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['scripinfo']}" 
        reportmsg(url)        
        
        values              = {}
        values["uid"]       = self.__username
        values["exch"]      = exchange
        values["token"]     = token       
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)

        if resDict['stat'] != 'Ok':            
            return None        

        return resDict

    def get_quotes(self, exchange, token):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['getquotes']}" 
        reportmsg(url)        
        
        values              = {}
        values["uid"]       = self.__username
        values["exch"]      = exchange
        values["token"]     = token       
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)

        if resDict['stat'] != 'Ok':            
            return None        

        return resDict

    def get_time_price_series(self, exchange, token, starttime=None, endtime=None, interval= None):
        '''
        gets the chart data 
        interval possible values 1, 3, 5 , 10, 15, 30, 60, 120, 240
        '''
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['TPSeries']}" 
        reportmsg(url)

        #prepare the data
        if starttime == None:
            timestring = time.strftime('%d-%m-%Y') + ' 00:00:00'
            timeobj = time.strptime(timestring,'%d-%m-%Y %H:%M:%S')
            starttime = time.mktime(timeobj)

        #
        values              = {'ordersource':'API'}
        values["uid"]       = self.__username
        values["exch"]      = exchange
        values["token"]     = token
        values["st"] = str(starttime)
        if endtime != None:
            values["et"]   = str(endtime)
        if interval != None:
            values["intrv"] = str(interval)

        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)
        
        #error is a json with stat and msg wchih we printed earlier.
        if type(resDict) != list:                            
                return None

        return resDict

    def get_daily_price_series(self, exchange, tradingsymbol, startdate=None, enddate=None):
        config = NorenApi.__service_config

        #prepare the uri
        #url = f"{config['eoddata_endpoint']}" 
        url = f"{config['host']}{config['routes']['get_daily_price_series']}" 
        reportmsg(url)

        #prepare the data
        if startdate == None:  
            week_ago = datetime.date.today() - datetime.timedelta(days=7)
            startdate = dt.combine(week_ago, dt.min.time()).timestamp()

        if enddate == None:            
            enddate = dt.now().timestamp()

        #
        values              = {}
        values["uid"]       = self.__username
        values["sym"]      = '{0}:{1}'.format(exchange, tradingsymbol)
        values["from"]     = str(startdate)
        values["to"]       = str(enddate)
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)

        reportmsg(payload)

        #headers = {"Content-Type": "application/json; charset=utf-8"}
        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res)

        if res.status_code != 200:
            return None

        if len(res.text) == 0:
            return None

        resDict = json.loads(res.text)
        
        #error is a json with stat and msg wchih we printed earlier.
        if type(resDict) != list:                            
            return None

        return resDict
        
    def get_holdings(self, product_type = None):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['holdings']}" 
        reportmsg(url)
        
        if product_type == None:
            product_type = ProductType.Delivery
        
        values              = {}
        values["uid"]       = self.__username
        values["actid"]     = self.__accountid
        values["prd"]       = product_type       
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)

        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)

        if type(resDict) != list:                            
                return None

        return resDict

    def get_limits(self, product_type = None, segment = None, exchange = None):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['limits']}" 
        reportmsg(url)        
        
        values              = {}
        values["uid"]       = self.__username
        values["actid"]     = self.__accountid
        
        if product_type != None:
            values["prd"]       = product_type       
        
        if product_type != None:
            values["seg"]       = segment       
        
        if exchange != None:
            values["exch"]       = exchange       
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)        

        return resDict

    def get_positions(self):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['positions']}" 
        reportmsg(url)        
        
        values              = {}
        values["uid"]       = self.__username
        values["actid"]     = self.__accountid
        
        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)
        
        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)

        if type(resDict) != list:                            
            return None

        return resDict

    def span_calculator(self,actid,positions:list):
        config = NorenApi.__service_config
        #prepare the uri
        url = f"{config['host']}{config['routes']['span_calculator']}" 
        reportmsg(url) 

        senddata = {}
        senddata['actid'] =self.__accountid 
        senddata['pos'] = positions
        #payload = 'jData=' + json.dumps(senddata,default=lambda o: o.encode())+ f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(senddata,default=lambda o: o.encode())

        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)        

        return resDict
        
    def option_greek(self,expiredate,StrikePrice,SpotPrice,InterestRate,Volatility,OptionType):
        config = NorenApi.__service_config 

        #prepare the uri
        url = f"{config['host']}{config['routes']['option_greek']}" 
        reportmsg(url)

        #prepare the data
        values               = { "source": "API" }
        values["actid"]     = self.__accountid
        values["exd"]        = expiredate
        values["strprc"]     = StrikePrice 
        values["sptprc"]     = SpotPrice
        values["int_rate"]   = InterestRate	
        values["volatility"] = Volatility
        values["optt"]       = OptionType

        #payload = 'jData=' + json.dumps(values) + f'&jKey={self.__susertoken}'
        payload = 'jData=' + json.dumps(values)

        reportmsg(payload)

        res = requests.post(url, data=payload, headers=self.__OAuthHeaders)
        reportmsg(res.text)

        resDict = json.loads(res.text)        

        return resDict
   
    def forgot_password_OTP(self, userid, pan):
        config = NorenApi.__service_config

        #prepare the uri
        url = f"{config['host']}{config['routes']['forgot_password_OTP']}" 
        reportmsg(url)

        #prepare the data
        values              = { "source": "API" }
        values["uid"]       = userid
        values["pan"]       = pan

        payload = 'jData=' + json.dumps(values)
        reportmsg("Req:" + payload)
        
        res = requests.post(url, data=payload)
        reportmsg(res.text)

        resDict = json.loads(res.text)        

        return resDict
